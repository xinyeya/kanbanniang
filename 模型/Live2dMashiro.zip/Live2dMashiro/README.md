# Live2dMashiro for emlog
emlog用的Live2d的看板娘——涅普迪努(Neptune)